﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PassSenderToClass
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //string str = ((TextBox)sender).Text;
        }

        protected void txtID_Load(object sender, EventArgs e)
        {
            string str = ((TextBox)sender).Text;
            clsTest obj = new clsTest();
            obj.Func(sender);
        }
    }

    public class clsTest
    {
        public void Func(object sender)
        {
            ((TextBox)sender).Text = ((TextBox)sender).Text.ToUpper();
        }
    }
}