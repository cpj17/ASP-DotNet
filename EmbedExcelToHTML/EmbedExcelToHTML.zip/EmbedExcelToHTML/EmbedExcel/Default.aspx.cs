﻿using System;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Office.Interop.Excel;
using Page = System.Web.UI.Page;

namespace EmbedExcel
{
    public partial class _Default : Page
    {
        string dynamicLink = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            string stringServerPath = "/ExcelToHTML/" + DateTime.Now.ToString("ddMMyyyy") + "/" + DateTime.Now.ToString("hhmmss");
            string stringExportPath = Server.MapPath(stringServerPath) + "/";
            if (!Directory.Exists(stringExportPath))
                Directory.CreateDirectory(stringExportPath);

            //string desktopTempPath = @"C:\Users\GSIAD-031\Desktop\temp\";
            string desktopTempPath = stringExportPath;
            byte[] excelBytes = GetExcelByteArray(); // Get the Excel byte array

            // Save the Excel byte array to a temporary file
            //string tempFilePath = Path.GetTempFileName();
            string tempFilePath = desktopTempPath + "temp_" + DateTime.Now.ToString("hhmmssffff") + ".tmp";
            File.WriteAllBytes(tempFilePath, excelBytes);

            // Create a new Excel Application instance
            Application excelApp = new Application();

            // Open the temporary file as a workbook
            Workbook workbook = excelApp.Workbooks.Open(tempFilePath);

            // Save the active sheet as HTML
            //string htmlFilePath = Path.GetTempFileName();
            string stringHtmlFileName = "out_" + DateTime.Now.ToString("hhmmssffff") + ".html";
            string htmlFilePath = desktopTempPath  + stringHtmlFileName;
            //workbook.ActiveSheet.SaveAs(htmlFilePath, XlFileFormat.xlHtml);

            //temp code (begins)
            foreach (Worksheet worksheet in workbook.Worksheets)
            {
                // Set border properties for each cell
                Range usedRange = worksheet.UsedRange;
                Borders borders = usedRange.Borders;
                borders.LineStyle = XlLineStyle.xlContinuous;
                borders.Weight = XlBorderWeight.xlThin;
            }

            // Save the workbook as HTML
            workbook.SaveAs(htmlFilePath, XlFileFormat.xlHtml);
            //temp code (ends)

            // Close the workbook and Excel application
            workbook.Close();
            excelApp.Quit();

            // Clean up the temporary files
            File.Delete(tempFilePath);
            //File.Delete(htmlFilePath);
            dynamicLink = stringServerPath + "/" + stringHtmlFileName;
        }

        static byte[] GetExcelByteArray()
        {
            byte[] excelBytes = File.ReadAllBytes(@"C:\Users\GSIAD-031\Desktop\a.xlsx");

            return excelBytes;
        }

        protected void btnRedirect_Click(object sender, EventArgs e)
        {
            // Register the client-side script to open the link in a new tab
            ScriptManager.RegisterStartupScript(this, GetType(), "OpenNewTab", "window.open('" + dynamicLink + "', '_blank');", true);
        }

    }
}